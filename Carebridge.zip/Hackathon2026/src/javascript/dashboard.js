import { auth, db } from "./firebase.js";
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {

if(user){

  try{
    let docSnap = await getDoc(doc(db, "users", user.uid));

    if(docSnap.exists()){

      let data = docSnap.data();

      // ✅ Name show (if element exists)
      let nameEl = document.getElementById("userName");
      if(nameEl){
        nameEl.innerText = data.name;
      }

      // ✅ Image show
      let imgEl = document.getElementById("userImage");
      if(imgEl){
        imgEl.src = `https://ui-avatars.com/api/?name=${data.name}&background=008080&color=fff`;
      }

      // ✅ OPTIONAL: role check (security)
      let currentPage = window.location.pathname;

      if(currentPage.includes("customer.html") && data.role !== "citizen"){
        alert("Access denied!");
        window.location.href = "../auth/login.html";
      }

      if(currentPage.includes("ngodashboard.html") && data.role !== "ngo"){
        alert("Access denied!");
        window.location.href = "../auth/login.html";
      }

    }else{
      alert("User data not found");
    }

  }catch(err){
    console.log(err);
  }

}else{
  // ❌ Not logged in
  window.location.href = "../auth/login.html";
}

});