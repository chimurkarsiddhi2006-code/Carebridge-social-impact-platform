
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAkhkASt7ieXpzKe5dT79o4etVHjkmFOgo",
  authDomain: "hackathon2026-82a6c.firebaseapp.com",
  projectId: "hackathon2026-82a6c",
  storageBucket: "hackathon2026-82a6c.firebasestorage.app",
  messagingSenderId: "504007883244",
  appId: "1:504007883244:web:dec500bb36c27a312da8c9",
  measurementId: "G-B033RT14FL"
 
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);