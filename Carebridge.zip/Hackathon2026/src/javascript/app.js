import { auth, db } from "./firebase.js";

import {
  doc, getDoc,
  collection, addDoc,
  serverTimestamp,
  getDocs,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";


// ================= USER PROFILE =================
onAuthStateChanged(auth, async (user) => {

if(user){

  try{
    let docSnap = await getDoc(doc(db, "users", user.uid));

    if(docSnap.exists()){

      let data = docSnap.data();

      // ✅ Name show
      let nameEl = document.getElementById("userName");
      if(nameEl){
        nameEl.innerText = data.name;
      }

      // ✅ Avatar
      let imgEl = document.getElementById("userImage");
      if(imgEl){
        imgEl.src = `https://ui-avatars.com/api/?name=${data.name}&background=008080&color=fff`;
      }

      // ✅ ROLE CHECK
      let page = window.location.pathname;

      if(page.includes("customer.html") && data.role !== "citizen"){
        alert("Access denied");
        window.location.href = "../auth/login.html";
      }

      if(page.includes("ngodashboard.html") && data.role !== "ngo"){
        alert("Access denied");
        window.location.href = "../auth/login.html";
      }

      // 👉 NGO page → load data
      if(page.includes("ngodashboard.html")){
        loadRequests();
      }

    }

  }catch(err){
    console.log(err);
  }

}else{
  window.location.href = "../auth/login.html";
}

});


// ================= CUSTOMER FORM =================
window.handleSubmit = async function(event, type){

event.preventDefault();

try{

const user = auth.currentUser;

if(!user){
  alert("Login required");
  return;
}

let data = {
  type: type,
  userId: user.uid,
  status: "Pending",
  createdAt: serverTimestamp()
};

// 🔥 form wise data
if(type === "Blood Request"){
  let inputs = event.target.querySelectorAll("input, select");

  data.patientName = inputs[0].value;
  data.bloodGroup = inputs[1].value;
  data.hospital = inputs[2].value;
}

if(type === "Public Complaint"){
  data.issueType = document.getElementById("issueType").value;
  data.description = document.getElementById("voiceText").value;
}

if(type === "Volunteer App"){
  let inputs = event.target.querySelectorAll("input, select, textarea");

  data.name = inputs[0].value;
  data.ngo = inputs[1].value;
  data.skills = inputs[2].value;
}

if(type === "Donation"){
  let inputs = event.target.querySelectorAll("select, input");

  data.ngo = inputs[0].value;
  data.amount = inputs[1].value;
}

// ✅ save
await addDoc(collection(db, "requests"), data);

alert(type + " submitted!");
event.target.reset();

}catch(err){
alert(err.message);
}

};


// ================= NGO DATA =================
async function loadRequests(){

let table = document.querySelector("tbody");

if(!table) return;

// 🔥 realtime update
onSnapshot(collection(db, "requests"), (snapshot) => {

table.innerHTML = "";

snapshot.forEach((doc) => {

let d = doc.data();

let row = `
<tr>
<td>${d.type}</td>
<td>${d.status}</td>
<td>${d.createdAt ? d.createdAt.toDate().toLocaleDateString() : "Now"}</td>
</tr>
`;

table.innerHTML += row;

});

});

}