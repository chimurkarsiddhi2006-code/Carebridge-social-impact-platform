import { auth, db } from "./firebase.js";

import { doc, setDoc, getDoc } 
from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

import {
createUserWithEmailAndPassword,
signInWithEmailAndPassword,
GoogleAuthProvider,
signInWithPopup,
sendEmailVerification,
signOut
} 
from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

const provider = new GoogleAuthProvider();


// ---------------- SIGNUP ----------------
window.signup = async function(){

let name = document.getElementById("name").value;
let email = document.getElementById("email").value;
let password = document.getElementById("password").value;
let role = document.getElementById("role").value;

// ✅ validation
if(!name || !email || !password || !role){
  alert("Please fill all fields");
  return;
}

try{

let userCredential = await createUserWithEmailAndPassword(auth,email,password);
let user = userCredential.user;

// email verification
await sendEmailVerification(user);

// save user in firestore
await setDoc(doc(db,"users",user.uid),{
  name: name,
  email: email,
  role: role
});

// 🔥 logout after signup
await signOut(auth);

alert("Signup successful! Please verify your email.");
window.location.href = "login.html";

}catch(error){

if(error.code === "auth/email-already-in-use"){
  alert("Email already registered! Please login.");
}else{
  alert(error.message);
}

}
}


// ---------------- LOGIN ----------------
window.login = async function(){

let email = document.getElementById("loginEmail").value;
let password = document.getElementById("loginPassword").value;

if(!email || !password){
  alert("Please enter email and password");
  return;
}

try{

let userCredential = await signInWithEmailAndPassword(auth,email,password);
let user = userCredential.user;

// // ✅ email verification check
// if(!user.emailVerified){
//   alert("Please verify your email first!");
//   return;
// }

// 🔥 get role from firestore
let docSnap = await getDoc(doc(db,"users",user.uid));

if(docSnap.exists()){

let role = docSnap.data().role;

// redirect based on role
if(role === "ngo"){
window.location.href = "../component/ngodashboard.html";
}
else if(role === "citizen"){
window.location.href = "../component/customer.html";
}
else if(role === "volunteer"){
window.location.href = "../component/volunteer.html";
}

}else{
alert("User data not found");
}

}catch(error){
alert(error.message);
}

}


// ---------------- GOOGLE LOGIN ----------------
window.googleLogin = async function(){

try{

let result = await signInWithPopup(auth,provider);
let user = result.user;

// check user exists
let docRef = doc(db,"users",user.uid);
let docSnap = await getDoc(docRef);

let role;

if(docSnap.exists()){
  role = docSnap.data().role;
}else{

  role = prompt("Enter role: citizen / ngo / volunteer");

  if(!["citizen","ngo","volunteer"].includes(role)){
    alert("Invalid role");
    return;
  }

  await setDoc(docRef,{
    name: user.displayName,
    email: user.email,
    role: role
  });
}

alert("Google Login Successful");

// redirect
if(role === "ngo"){
window.location.href = "../component/ngodashboard.html";
}
else if(role === "citizen"){
window.location.href = "../component/customer.html";
}
else if(role === "volunteer"){
window.location.href = "../component/customer.html";
}

}catch(error){
alert(error.message);
}

}


// ---------------- LOGOUT (OPTIONAL) ----------------
window.logout = async function(){

await signOut(auth);
alert("Logged out successfully");
window.location.href = "../auth/login.html";

}